# -*- coding: utf-8 -*-
"""
Created on Mon Mar 16 20:32:29 2020

@author: Chantale Gihara

#Semesterarbeit Teil 2 - Erstellung von Graphiken mit Matplotlib

***Aufgabenstellung:***
    
Erstellen Sie eine Beispielsammlung von verschiedenen Arten von Graphiken mit Matplotlib; es sollte je ein Beispiel der folgenden Diagrammtypen berücksichtigt werden:

- Funktionsgraphen, 
- Mehrere Funktionsgraphen in der selben Graphik,
- Balkendiagramme,
- Totendiagramme,
- Histogramme.
"""

import matplotlib.pyplot as plt
import csv
import numpy as np
from datetime import datetime

"""

#Funktionsgraphen:

Es gibt verschiedene Arten von Funktionen: ich werde folgende Funktionen in dieser Arbeit graphisch darstellen:
    - Quadratische Funktion auch Polynomfunktion zweiten Grades genannt
    - Lineare Funktion
    - Exponentielle Funktion

#Beschreibung und Eingaben der Quadratischen Funktion
- Funktion der Form y=f(x) = ax<sup>2</sup> + bx + c, wenn a != 0, heissen quadratische Funktionen
oder auch Polynomfunktionen zweiten Grades. 
- Der Graph der quadratischen Funktion heisst <b>Parabel</b>

-Jede Lösung der Gleichung 0 = ax<sup>2</sup>+ bx + c ist eine Nullstelle der Funktion f(x) = ax<sup>2</sup>+bx+c
- Die Spitze der der Parabel heisst Scheitelpunkt S.

#Beschreibung und Eingaben der Linearen Funktion
Eine sehr wichtige und grundlegende Funktionsart ist die lineare Funktion.
Sie hat allgemein die folgende Vorschrift: f(x) = (mx + b) - z
- b = heisst y-Achsenabschnitt oder konstantes Glied

- Der Graph einer linearen Funktion ist eine Gerade. 
- m heisst Steigung oder Proportionalitätsfaktor 'm = (y0 - y1) / (x0 - x1)'

Dafür müssen x-Wert wie auch y-Werte in Arrays aufgenommen werden. 

Um mit den Funktionen zu spielen in den Graphen nehmen wir noch eine Konstante an z,
mit welcher die Funktion an der x-Achse hin und her geschoben werden kann.


"""
"""
##Quadratische Funktion

"""

# Eingabe der Funktion
# Folgende Funktion wird hier berechnet: ax<sup>2</sup> + bx + c
print('Bitte Parameter eingeben')
a = float(input('Parameter a: '))
b = float(input('Parameter b: '))
c = float(input('Parameter c: '))
x = np.arange(-67,67,1)

k = [a,b,c] #Koeffizienten
null = np.roots(k)   #Berechnet die Nullstelle Koeffizienten
k1 = [2*a,b]  #Erste Ableitung der Funktion
sx = np.roots(k)   #Scheitelpunkt X-Koordinate
sy = a*sx**2+b*sx+c  #Scheitelpunkt Y-Koordinate
sp = [sx, sy] # Scheitelpunkt
print('Die Nullstellen liegen bei: ')
print(null)
print('Der Scheitelpunkt liegt bei: ')
print(sp)



def quadratischef():
    y = []
    for i in x:
        y.append(a*(pow(i,2))+ (b*i) +c)
    return y
qfy = np.array(quadratischef())
plt.plot(x,qfy)
plt.title('Quadratische Funktion (Polynom 2. Grades')
plt.xlabel('x - Achse')
plt.ylabel('y - Achse')
plt.show()


"""
##Lineare Funktionen
"""

#Lineare Funktion 1

x = np.arange(-25,25,1)# x in der Range von -255 bis 25 aufsteigend +1

m = float(input('geben Sie die gewünschte Steigung für die lineare Funktion 1 ein:  '))
c = float(input('geben Sie das gewünschte konstante Glied für die linear Funktion 2 ein:  '))

def linearf1():
    y = []
    for i in x:
      y.append(m*i + c) 
    return y
fy = np.array(linearf1()) # y Werte werden in einen Array geladen

#Lineare Funktion 2
    
m1 = float(input('geben Sie die gewünschte Steigung für die lineare Funktion 2 ein:  '))
c1 = float(input('geben Sie das gewünschte konstante Glied für die linear Funktion 2 ein:  '))

x1 = np.arange(-6,35,2) # x1 in der Range von -6 bis 35 aufsteigend +2
def linearf2():
    y1 = []
    for n in x1:
        y1.append(m1*n +c1) 
    return y1

fy1 = np.array(linearf2()) # y1 Werte werden in einen Array geladen

plt.xlabel('x-Achse')
plt.ylabel('y-Achse')
plt.plot(x, fy, 'o', label='erste Funkton f1') # Funktion wir als Punkte-Graph abgebildet 
plt.plot(x1,fy1, '', label='zweite Funktion f2')# Funktion wir als Linie abgebildet
plt.title('Lineare Funktionen') # Titel für den Graphen
plt.legend() # Legende wird angezeigt
plt.show() 

"""
Balkendiagramm mit der Benutzung der Funktionen
"""

#graphische Ausgabe Balkendiagramm der obenstehenden Funktionen
plt.bar(x, quadratischef(),label='quadratische Funktion', color='r')
plt.bar(x, linearf1(), label='lineare Funktion', color='b')
plt.xlabel('x Value')
plt.ylabel('y Value')
plt.title('Balkendiagramm mit linearer und quadratischer Funktion')
plt.legend()
plt.show()


"""
##Balkendiagramm mit einem CSV Import aus https://ourworldindata.org/coronavirus-source-data

Our World Data trackt Daten aus der ganzen Welt. Momentan beschäftigt der Corona Virus die ganze Welt,
deswegen dachte ich es sei spannend diese Daten in einem csv-File auszulesen.

"""

dates=[]
deaths=[]

path = 'data_World.txt'
file = open(path, newline='')
reader = csv.reader(file, delimiter=',')
header = next(reader) # die erste Linie ist ein Header (Kopfzeile)

dates=[]
dates_postive_tested=[]
deaths=[]
positive_tested=[]

for row in reader: 
    # row = [Date , World]
    x = datetime.strptime(row[0], '%d-%b-%y') #Konvertiert den String in ein das angegebene Datenformat
    y = int(row[6]) #Konvertiert den String in ein Integer
    z = int(row[5])
    dates_postive_tested.append(x)
    dates.append(x) 
    deaths.append(y)
    positive_tested.append(z/100)

plt.bar(dates, deaths, label='Number of deaths of COVID-19', align='center', color='r')# Farbe und Label vom Balkendiagramm
plt.bar(dates_postive_tested, positive_tested, width=0.8, label='Number of positive tested COVID-19 in hundreds ',color='b' )
plt.xticks(rotation=90) # Rotiert um 90 Grad die Label an der x-Achse
plt.xlabel('x= dates')
plt.ylabel('y= number')
plt.title('number of deaths of COVID-19')
plt.legend()
plt.show()

"""
Am Balkendiagramm kann man sehr schön erkennen wie die Anzahl der Infizierten exponentiell wächst.
Die Toten verlaufen noch etwas linearer, jedoch kann man sehen, dass auch im März die Anzahl
der Toten schneller wächst, da es halt auch exponentiell höhere Infizierte hat, und somit auch die toten,
exponentiell zunehmen werden.
"""

"""
## Histogramm mit einem CSV Import aus https://ourworldindata.org/coronavirus-source-data

"""
dates=[]
deaths=[]

path = 'total_deaths.txt'
file = open(path, newline='')
reader = csv.reader(file, delimiter=',')
header = next(reader) # die erste Linie ist ein Header (Kopfzeile)

dates=[]
deaths=[]

for row in reader: 
    # row = [Date , World]
    x = datetime.strptime(row[0], '%d-%b-%y') #Konvertiert den String in ein das angegebene Datenformat
    y = int(row[2])
    dates.append(x) 
    deaths.append(y)
    
bins = [0,5000,10000,15000]
plt.hist(deaths, bins ,label='Number of deaths of COVID-19 in constant day of Category:\n'
         +' 0,5000,10000,15000', color='g')# Farbe und Label vom Histogramm
plt.xticks(rotation=90) # Rotiert um 90 Grad die Label an der x-Achse
plt.xlabel('x= number of deaths')
plt.ylabel('y= number of days it needs to change the death cathegory')
plt.title('number of deaths of COVID-19')
plt.legend(loc='upper center')
plt.show()
"""
Es brauchte 74 Tage bis die Kategorie 5000 Tote weltweit erreicht wurde. 
Danach brauchte es nur noch 7 Tage bis die nächste Anzahlskategorie von 10000 erreicht wurde.
Stand 21.03.2020 sind es 11252 Tote. Die Anzahl toten steigen als exponetiell.  
"""
"""
## Totendiagramm mit einem CSV Import aus https://ourworldindata.org/coronavirus-source-data
"""
deaths_Dec=[]
deaths_Jan=[]
deaths_Feb=[]
deaths_Mar=[]
x=[]
cols = ['c', 'r', 'g', 'b'] # Definierte Farben für den Pie
with open('total_deaths.txt','r') as csvfile: #öffnet das Dokument
    plots =csv.reader(csvfile, delimiter=',') #hier wird das Dokument ausgelesen nach delimiter , und wird in plots geladen
    next(plots, None) #überspringt header
    for row in plots: 
        #Vergleicht die row mit dem Monat
        if int(row[1]) == 12: 
            deaths_Dec.append(int(row[3]))
        if int(row[1]) == 1: 
            deaths_Jan.append(int(row[3]))
        if int(row[1]) == 2: 
            deaths_Feb.append(int(row[3]))
        else:
            deaths_Mar.append(int(row[3]))
            
#Berechnet den Durchschnitt der Monate und lated es in eine Variable
pie_deaths_Dec = round(np.mean(deaths_Dec),0) 
pie_deaths_Jan = round(np.mean(deaths_Jan),0)
pie_deaths_Feb = round(np.mean(deaths_Feb),0)
pie_deaths_Mar = round(np.mean(deaths_Mar),0)


#Hier werden die berechneten Daten in ein Pie geplottet
plt.pie([pie_deaths_Dec,pie_deaths_Jan, pie_deaths_Feb, pie_deaths_Mar],
        labels= ['Durchschnitt Tote im Dez:\n '+ str(pie_deaths_Dec),'Durchschnitt Tote im Jan:\n '+ str(pie_deaths_Jan), 
                 'Durchschnitt Tote im Feb:\n '+ str(pie_deaths_Feb), 'Durchschnitt Tote im Mär:\n '+ str(pie_deaths_Mar)],
        colors=cols, #Farben
        startangle=90, #Startwinkel ist 90 Grad
        shadow=True,
        explode=(0,0,0.1,0), #stellt ein Tortenteil heraus
        autopct='%1.0f%%') #Anzeige ohne Dezimalangaben.
plt.title('Durschnitt Tote pro Monat durch COVID-19')
plt.show()
"""
Die Anzahl Tote in Prozenten pro Monat werden sich pro Monat verdoppeln, 
da der März auch noch nicht ganz am Ende ist (Stand 21.03.2020).

"""
"""
##Schlusswort:

Die Zahlen sind beängstigend und mit diesen Imports einfach zu analysieren. 
Man kann einfach die Dokumente täglich vom Server ziehen und dank den Graphen können die Auswertungen einfach interpretiert werden


"""