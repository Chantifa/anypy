'''
File name: Semesterarbeit_Teil_1a_Fibonacci-Folge.py
Author: Chantale Gihara
Date created: 12/02/2020
Date last modified: 24/02/2020
Python Version: 3.7  
'''
''' 
Date last modified: 26/02/2020

Python Version: 3.7  

## Einleitung
Die Fibonacci-Folge ist eine unendliche Folge von Zahlen, bei der sich die jeweils folgende Zahl durch Addition ihrer beiden vorherigen 
Zahlen zusammenzählt.

Die Fibonacci-Folge:

- 'a<sub>0</sub> = 1'
- 'a<sub>1</sub> = 2'
- 'a<sub>2</sub> = 3'
- 'a<sub>3</sub> = 5'

berechnet sich wie folgt: n = (n-2) + (n-1).

Wie kam es zu dieser Folge?
Gemäss der Quelle http://members.chello.at/gut.jutta.gerhard/fibonacci.htm hat der italienische Mathematiker Fibonacci (eigentlich Leonardo von Pisa, 1170 - 1250) folgende Aufgabe gestellt:

*Ein Mann hält ein Kaninchenpaar an einem Ort, der gänzlich von einer Mauer umgeben ist. Nun wollte er genau wissen, wie viele Paare von ihnen in einem Jahr gezüchtet werden können, wenn die Natur es so eingerichtet hat, dass diese Kaninchen jeden Monat ein weiteres Paar zur Welt bringen und damit im zweiten Monat nach ihrer Geburt beginnen. So beschrieb L.Fibonacci mit dieser Folge im Jahre 1202 das Wachstum einer Kaninchenpopulation.*

Die Fibonnaci-Folge kann in verschieden Algorithmen berechnet werden. Dazu muss die Anzahl der Aufrufe und Operationen gemäss Laufzeitberechnung beobachtet werden. 
Hier werden 3 verschiedene Methoden benutzt welche ausgeführt und danach gegenübergestellt werden.

- die rekursive naive Formel
- eine effizientere rekursive Formel
- die effizente iterative Formel:
'''



'''
## Rekursive naive Formel
Man kann die Fibonacci-Folge mit Hilfe des folgendem rekursiven Bildungsgesetzes und den Anfangswerten f<sub>0</sub> = 0 und f<sub>1</sub> = 1 berechnen.

Jede folgende Zahl ist die Summe ihrer beiden vorherigen Zahlen

 => f<sub>n</sub> = f(n−1) + f(n−2) für n ≥ 2
 
Jedoch gibt es bei dieser Folge einen Nachteil: *Die Laufzeit steigt exponentiell n<sup>x</sup>.*

Im Laufe der Berechnung von Fibonnaci(n) werden die Werte der 
<b>Folge für kleinere n immer wieder berechnet</b>, 
eine grosse Verschwendung der Berechnungszeit. Diese Folge wächst daher schneller als die Fibonacci-Folge. 
Vereinfacht, die Anzahl der Operationen zur Berechnung von F(n) 
ist proportional zur endgültigen numerischen Antwort, die exponentiell wächst. 

Um das Ganze danach besser zu analysieren wird ein Objekt «counter» hinzugefügt, 
womit wir später sehen wie viele Male eine Funktion aufgerufen wird um eine Rechenoperation durchzuführen.
'''
import sys
from time import time
import numpy as np
import matplotlib.pyplot as plt

counter = [0] #Zählt die Funktionsaufrufe

def fib_naive(n):
    counter[0] += 1 #Zählt 1 hoch nach jedem Aufruf
    #überprüfen ob n gleich oder grösser als 1 ist
    if n <= 1: 
    #wenn n gleich oder grösser als 2 ist dann gilt für n => fn=f(n-1)+f(n-2) und dann zurückgeben fn=f(n-1)+f(n-2) für n ≥ 2
        return n
    else:
        return fib_naive(n - 1) + fib_naive(n - 2)  #Funktion wird erneut aufgerufen mit neu berechnetem Wert (n-1) + (n-2)
    
'''
Berechne die Aufrufe der Funktion der nten Fibonnaccizahl
'''

def count(n):
    fib_naive(n) #Aufruf der nten Fibonnaccifolge
    print('Die Funktion wird:',counter[0],'aufgerufen') #drucke das Objekt counter aus
    return counter[0] # gib das Objekt counter zurück
'''
Vergleichen der Aufrufe der Folgen 35. bis 40. Fibonnaci-Zahl:
'''
def compare(): #Vergleiche die Aufrufe gmäss der berechneten Fibonaccizahl
    y = []
    for i in range(35,40): #Fibonnaci-Folge 
        print('Fibonnacci-Zahl :',fib_naive(i)) #druckt die Fibonaccizahl
        y.append(count(i)) #packt die gezählten Aufrufe in das Objekt y
    return y #Objekt wird zurückgegeben

z = compare() # Aufruf der Verleichen Funktion
x = np.arange(35,40,1) # xWerte von 35 bis 40 aufzählend +1
y = np.array(z) #Variable wird in ein Array konvertiert
print(y)
plt.xlabel('Fibonnacifolge')
plt.ylabel('Funktionsaufrufe in Milliarden pro Fibonnaccizahl-Berechnung ')
plt.plot(x, y/1000000000, '') # Graph zeichnen 
plt.show()

'''
## Effiziente Rekursive Formel
Um die Fibonacci-Folge etwas effizienter zu gestalten kann man eine Funktion in einer Funktion verpacken. 
Beim Eintreffen der Inneren Funktion wird der Wert in die Äussere übertragen. 
So wird bei der verpackten Funktion nur auf eine Funktion aufgerufen und 
somit haben wir hier keine kein exponentielles Wachstum der Folgen-Funktionsaufrufe.
Dieser Algorithmus benötigt O(1) Platz und O(n) Operationen.
 
'''

def fib_efficient(n):
    def fib_internal(a, b, n):#Hier startet die innere Funktion a =n-2, b=n-1
        if n == 0: #falls n 0 ist wird b als Rückgabewert gegeben und die innere Funktion ist beendet.
            return b
        else:
            return fib_internal(b, a + b, n - 1) #innere Funktion wird rekursiv aufgerufen a => b und b => a+b, n => n-1
    if n <= 1: #n ist kleiner oder gleich 1 so wird der Rückgabewert n sein und die äussere Funktion endet
        return n 
    else:
        return fib_internal(0, 1, n - 1)#wenn grösser als 1, dann wir die interne Funktion aufgerufen a=>0, b=>1 und n=>n-1
'''
## Effiziente Itertive Formel
Möchte man eine Funktion, die für einen möglichst grosse Werte von n in der Lage ist, 
das nte Glied der Fibonacci-Folge zu berechnen, so kann man das in einer Schleife tun, 
die aus den ersten beiden Werten den dritten, aus dem zweiten und dritten, 
den vierten usw. bis zum nten berechnet. Ist eigentlich aufgebaut wie die fib_efficient, 
 anstatt in einer verpackten Funktion, die Werte direkt zugeteilt. 
 Zeitlich kommt es aufs Gleiche O(1) Platz und O(n) Operationen.
'''
def fib_iterative(n):
    if n <= 1: #n ist kleiner oder gleich 1 so wird der Rückgabewert n sein und die äussere Funktion endet
        return n
    a = 0 #start Wert für a => 0
    b = 1 #start Wert für b => 1
    for i in range(n - 1): #Schlaufe für jedes n welches aufgerufen wird
        c = a + b  #c eine temporäre Variable die erstellt wird, um die Werte zu swapen
        a = b
        b = c
    return b
'''
***Eine elegantere Lösung ist die Laufzeit der Funktionen gegenüber zustellen:***
Funktion für die Laufzeit der Fibonacci-Folgeberechnung pro Funkton f.

Um das Ganze noch etwas anschaulicher zu machen, 
stelle ich die Laufzeit der verschiedenen Methoden noch graphisch dar.

'''
#Funktion für die Laufzeit der Fibonacci-Folgeberechnung pro Funkton f
def duration(f): #Funktion der Laufzeitberechnung
    start = time() #Startzeit der Funktionsberchnung in Sekunden
    sys.stdout.write(" {} ".format(f())) #übernimmt und schreibt den Funktionswert aus in der Formatierung
    end = time() #Endzeit der Funktionsberechnung abgeschlossen in Sekunden
    duration = end -start
    print("duration: {:6.3f}".format(duration)) # druckt und angehängt an die Formatierung, die Laufzeit aus.
    return duration

def test(label, f): #Funktion pro gestete Fibonacci-Folge
    print(label) #Druckt das Label aus.
    y = []
    for n in range(35, 40): #n in der Range von 35 - 40
        sys.stdout.write(" {:3d} ".format(n)) #Ausgabe wird in Formatierung ausgedruckt.
        y.append(duration(lambda: f(n))) #Funktion der Laufzeit wird aufgerufen
    return y

ys = test("efficient recursive", fib_efficient) #Funktion test wird Aufgerufen und wird in eine Variable gepackt.
ys1 = test("efficient iterative", fib_iterative)
ys2 = test("naive recursive", fib_naive)
yz=np.array(ys) #Variable wird in ein Array konvertiert
yz1=np.array(ys1)
yz2=np.array(ys2)

xs = np.arange(35,40,1) # xWerte von 35 bis 40 aufzählend +1
plt.xlabel('Fibonnacifolge')
plt.ylabel('Laufzeit in Sekunden')
plt.plot(xs, yz, 'o') # Graph zeichnen 
plt.plot(xs, yz1, '')
plt.plot(xs, yz2, '')
plt.show()

"""
## Erkenntnisse
Die Ergebnisse mit den Fibonaccifolgen von 35 von 40, zeigen hauptsächlich, dass die naive rekursive Funktion "fib_naive" in der Laufzeit die anderen Funktionen signifikant überholt. Dieser Algorithmus ist für grössere n zur Berechnung der Fibonacci-Zahlen überhaupt nicht empfehlenswert. Die Funktion wäschst exponentiell, wo die anderen nur O(1) für den Speicher und O(n) für den Berechnung brauchen. Die Graphiken stellen das sehr schön dar. Bei den effizienten Lösungen ist man im Nanosekundenbereich und deshalb mit time() im Sekundenbereich nicht ersichtlich.
Diese Funktionen sind aber sehr effizient und könnten so gut eingesetzt werden.
"""
